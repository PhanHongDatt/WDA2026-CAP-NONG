import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: ["/dashboard/", "/checkout/", "/cart/"],
      },
    ],
    sitemap: "https://capnong.vn/sitemap.xml",
  };
}
